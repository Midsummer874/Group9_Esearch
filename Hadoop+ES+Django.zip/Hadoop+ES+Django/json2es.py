# -*- coding: utf-8 -*-

import sys
import time
from elasticsearch import Elasticsearch
from elasticsearch import helpers

"""
代码说明：通过bulk的方式将数据写入es
使用方法：python json2es.py indexName fileName
数据查看：localhost:9100
"""

es = Elasticsearch(hosts=["localhost"])


def input_es(index_name, input_file):
    """
    通过elasticsearch的bulk接口将数据直接写入index
    :param index_name:
    :param input_file:
    :return:
    """
    try:
        with open(input_file, 'r') as f:
            data = f.read().split('\n')
            data = list(filter(None, data))
            print('data rows: {}Rows'.format(len(data)))
            # 按index的数据格式，并创建生成器防止内存溢出
            action = ({
                '_index': str(index_name),
                '_source': d
            } for d in data)
            # 将生成器提交给es创建index
            helpers.bulk(es, action)
    except Exception as e:
        raise e


if __name__ == '__main__':
    t1 = time.time()
    index = sys.argv[1] if len(sys.argv) >= 3 else None
    filename = sys.argv[2] if len(sys.argv) >= 3 else None
    input_es(index, filename)
    t2 = time.time()
    print('used time: {}s'.format((t2 - t1)))
