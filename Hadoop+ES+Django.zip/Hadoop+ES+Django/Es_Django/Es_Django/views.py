from django.shortcuts import render
from elasticsearch import Elasticsearch


class CustomES:
    def __init__(self):
        self.client = Elasticsearch(hosts=["Localhost"])

    def search(self, key_words, page, size):
        page = int(page) if page else 1
        size = int(size) if size else 10
        result = self.client.search(
            index="index_1",
            body={
                "query": {
                    "multi_match": {
                        "query": key_words,
                        "fields": ["secure"]
                    }
                },
                "from": (page - 1) * size,
                "size": size,
                "highlight": {
                    "pre_tags": ['<span class="keyWord">'],
                    "post_tags": ['</span>'],
                    "fields": {
                        "secure": {}
                    }
                }
            }
        )
        
        total_nums = result['hits']['total']['value']
        
        result_data = result['hits']['hits']
        
        hit_list = []
        for data in result_data:
            hit_dict = {'title': ''.join(data['highlight']['secure']),
                        'data': data['_source']['secure'],
                        'score': data['_score']}
            hit_list.append(hit_dict)
        

        search_result = {
            'key_words': key_words,
            'current_page': page,
            'page_size': size,
            'total_nums': total_nums,
            'search_res': hit_list
        }
        return search_result


def index(request):
    return render(request, 'index.html')


def query(request):
    key = request.GET.get('key')
    page = request.GET.get('page')
    if not key:
        return render(request, 'index.html')
    es = CustomES()
    size = 20
    result: dict = es.search(key, page, size)
    
    return render(request, 'result.html', result)


if __name__ == '__main__':
    es = CustomES()
    res = es.search('root', 2, 10)
    print(res)
