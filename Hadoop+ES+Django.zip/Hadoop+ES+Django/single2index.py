# -*- coding: utf-8 -*-

import os
import sys
import time
import operator
from functools import reduce
from collections import Counter
from collections import defaultdict



def create_index(file_dir):
    word_dict_list = []
    for file in os.listdir(file_dir):
        word_file_dict = defaultdict(list)
        file_path = os.path.join(file_dir, file)
        with open(file_path, 'r') as f:
            file_data = f.read().split('\n')
        
        word_data = [data.split(' ') for data in file_data]
        
        word_list = [i for j in word_data for i in j]
        
        word_dict = Counter(list(filter(None, word_list)))
        
        for word, count in word_dict.items():
           
            word_file_dict[word].append((file, count))
        word_dict_list.append(word_file_dict)


    word_file_dict = defaultdict(list)
    for word_dict in word_dict_list:
        
        for word, file_count in word_dict.items():
            word_file_dict[word].append(file_count)

    
    word_file = defaultdict(list)
    for word, file_count in word_file_dict.items():
       
        values_list = reduce(operator.add, file_count)
        
        values_sort = sorted(values_list, key=lambda x: x[1], reverse=True)
       
        file_list = [i[0] for i in values_sort]
       
        word_file[word] = file_list
    
    print(word_file)
    return word_file


if __name__ == '__main__':
    t1 = time.time()
    
    file_path = sys.argv[1] if len(sys.argv) >= 2 else None
    index = create_index(file_path)
    search_words = ['linux', 'mysql', 'postgres', 'cracker', 'authentication', 'knowledge']
    for w in search_words:
        res = index.get(w)
        print(w, res)
    t2 = time.time()
    print('used time: {}s'.format(t2 - t1))
