# -*- coding: utf-8 -*-

import os
import re
import sys
import string




def clean_text(input_str):
    
    remove_nums = re.sub(r'[0-9]', ' ', input_str)
    # Get rid of punctuation and number
    remove_punc = re.sub('[%s]' % re.escape(string.punctuation), ' ', remove_nums)
   
    
    split_words = remove_punc.split()
    return split_words


def split_data(filename):
    with open(filename, 'r') as f:
        file_data = f.read().split('\n')
        file_data = list(filter(None, file_data))
    clean_data = [clean_text(str(i).lower()) for i in file_data]
    

    # Creates an empty directory for syslog_split
    file_path = filename + '_split'
    if not os.path.exists(file_path):
        os.makedirs(file_path)

    
    lines_nums = 10000
    chunk_data = [clean_data[i:i + lines_nums] for i in range(0, len(clean_data), lines_nums)]

    
    for i in range(len(chunk_data)):
        
        split_name = 'doc_' + str(i).zfill(2)
        
        split_file = os.path.join(file_path, split_name)
        with open(split_file, 'w') as f:
            for line in chunk_data[i]:
                
                line_data = ' '.join(line)
                f.write(line_data + '\n')


if __name__ == '__main__':
    filename = sys.argv[1] if len(sys.argv) >= 2 else None
    split_data(filename)
