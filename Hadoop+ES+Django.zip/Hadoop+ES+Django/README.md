# Explaination
- Single2Index.py
Just use command "Python single2index.py syslog_small(large)” in terminal

- Lucene2Index.java 
- Just run the program in Intellij IDEA, with maven dependence

- MapReduce2Index.java
- It should be run with Hadoop

- Log2Split.py & json2es.py
- It can be run in terminal with python