import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;


public class Lucene2Index {

    public static void main(String[] args) throws Exception {
        long startTime = System.currentTimeMillis();
        
        Directory dir = new RAMDirectory();
        new Lucene2Index().createIndex(dir);
        
        String[] searchWords = new String[]{"linux", "mysql", "postgres", "cracker", "knowledge"};
        for (String word : searchWords) {
            System.out.print(word + ": ");
            new Lucene2Index().search(dir, word);
            System.out.println();
        }
        long finishTime = System.currentTimeMillis();
        System.out.println("used time: " + (finishTime - startTime) + "ms");
    }

   
    private void createIndex(Directory dir) throws IOException {
        IndexWriter indexWriter;

       
        Analyzer analyzer = new StandardAnalyzer();
        IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
        indexWriter = new IndexWriter(dir, iwc);

        
        Document document;


        String filePath = "C:\\Users\\DELL\\Desktop\\UIC Y3\\workshop II\\Hadoop+ES+Django\\syslog_small";

        File file = new File(filePath);
        File[] fs = file.listFiles();
        assert fs != null;
        for (File f : fs) {
            document = new Document();
            
            document.add(new Field("content", FileUtils.readFileToString(f, "utf-8"), TextField.TYPE_STORED));
            document.add(new TextField("fileName", f.getName(), Field.Store.YES));
            document.add(new StringField("filePath", f.getAbsolutePath(), Field.Store.YES));
            
            indexWriter.addDocument(document);
        }
        indexWriter.close();
    }

    
    private void search(Directory dir, String queryWord) throws Exception {
        IndexReader indexReader;

        
        indexReader = DirectoryReader.open(dir);

        
        IndexSearcher indexSearcher = new IndexSearcher(indexReader);

        
        QueryParser queryParser = new QueryParser("content", new StandardAnalyzer());

        
        Query query = queryParser.parse(queryWord);

        
        TopDocs topDocs = indexSearcher.search(query, 10);

        
        ScoreDoc[] socreDocs = topDocs.scoreDocs;

        for (ScoreDoc doc : socreDocs) {
            
            Document document = indexSearcher.doc(doc.doc);

           
            System.out.print(document.get("fileName") + " ");
            
        }
        indexReader.close();
    }

}
